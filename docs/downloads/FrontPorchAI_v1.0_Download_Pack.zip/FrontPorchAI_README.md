# FrontPorchAI

**AI on the Front Porch: A Family Bridge for Understanding Artificial Intelligence**

FrontPorchAI is a plainspoken family education resource for helping skeptical, rural, faith-shaped, practical, or family-centered readers understand AI without fear, hype, or blind trust.

## Core sentence

> AI is not replacing my heart; it is helping me use my heart better - when I keep truth, love, privacy, humility, and human responsibility in charge.

## What this repo contains

- Interactive JSX companion experience
- Full v1.0 community bridge paper
- Printable family handout
- Prompt cards for safe first use
- Truth-check ladder
- Privacy and safety boundaries
- Family night walkthrough

## Positioning

This is an educational resource / position paper, not a scientific study. It is designed to help families have better conversations about AI while keeping human responsibility at the center.

## Recommended license

Creative Commons Attribution 4.0 International (CC BY 4.0), if you want people to share and adapt the resource with attribution.

## Suggested publication flow

1. Host the interactive JSX version with GitHub Pages.
2. Put PDF and DOCX versions in `/docs`.
3. If creating a DOI later, deposit the PDF as the citable record and link to the live GitHub Pages version.
4. Tag releases as `v1.0`, `v1.1`, etc.

## Authorship transparency

This resource was human-directed and human-owned by Michael W. Hughes. AI assistance was used for drafting, organizing, refinement, and review. Final responsibility remains human.
